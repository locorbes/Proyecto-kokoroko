#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED


void apply_surface( int x, int y, SDL_Surface* source, SDL_Surface* destination){
    //Holds offsets
    SDL_Rect* clip = NULL;
    SDL_Rect offset;

    //Get offsets
    offset.x = x;
    offset.y = y;

    //Blit
    SDL_BlitSurface(source, clip, destination, &offset );
}

bool alert_message(int ancho, int alto, char *texto, SDL_Surface* pantalla){
    bool pregunta=true;
    SDL_Surface *mensaje = NULL;
    SDL_Surface *alerta = NULL;
    TTF_Font *fuente = NULL;
    SDL_Color negro = {18, 18, 18};
    fuente = TTF_OpenFont("fonts/visitor.ttf", 22);

    mensaje = TTF_RenderText_Solid(fuente, texto, negro);
    alerta = IMG_Load("images/alerta.png");
    SDL_Event evento;

    apply_surface( ancho/2-129, alto/2-81, alerta, pantalla);
    apply_surface( ancho/2-110, alto/2-20, mensaje, pantalla);
    SDL_Flip(pantalla);

    while(pregunta){
        while( SDL_PollEvent(&evento) ){
            if( evento.type == SDL_MOUSEBUTTONUP){
                if((evento.button.x>ancho/2+96&&evento.button.x<ancho/2+128)&&(evento.button.y>alto/2-80&&evento.button.y<alto/2-48)){
                    //BOTON X
                    return false;
                }
                if((evento.button.x>ancho/2-110&&evento.button.x<ancho/2-8)&&(evento.button.y>alto/2+32&&evento.button.y<alto/2+64)){
                    //BOTON CANCELAR
                    return false;
                }
                if((evento.button.x>ancho/2+8&&evento.button.x<ancho/2+110)&&(evento.button.y>alto/2+32&&evento.button.y<alto/2+64)){
                    //BOTON CREAR
                    return true;
                }
            }
        }
    }
    return false;
}

Nivel buscarNivel(int id){
    Nivel reg;
    FILE*archivo;
    archivo=fopen("DATA/niveles.dat", "rb");

    fseek(archivo, id*sizeof reg, SEEK_SET);
    fread(&reg, sizeof reg, 1, archivo);
    fclose(archivo);

    return reg;
}

int contarNiveles(){
    long tam;
    FILE * archivo;
    archivo=fopen("DATA/niveles.dat", "rb");
    if(archivo!=NULL){
        fseek(archivo, 0, SEEK_END);
        tam = ftell(archivo);
        fclose(archivo);
        return tam/sizeof(Nivel);
    }else{
        fclose(archivo);
        return 0;
    }

}
void mostrarNumero(int n, int x, int y, SDL_Surface *pantalla){
    SDL_Surface *numero = NULL;
    TTF_Font *visitor = NULL;
    visitor = TTF_OpenFont("fonts/arial.ttf", 18);
    SDL_Color negro = {18, 18, 18};
    Uint32 onBlur=SDL_MapRGB(pantalla->format, 0xa8, 0xa8,0xa8);
    SDL_Rect dim;

    char buffer[2];
    sprintf (buffer, "%d", n);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={x, y, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(x, y, numero, pantalla);
    SDL_FreeSurface(numero);

}

int contarSecciones(){
    int cont = contarNiveles()/3;
    int rest = contarNiveles()%3;
    if(rest>0){cont++;}
    return cont;
}

char *escribir(char *palabra, int x, int y, SDL_Surface *pantalla){
    bool salir=false;
    int i, pos=0;
    SDL_Surface *texto = NULL;
    TTF_Font *fuente = NULL;
    SDL_Rect dim;
    SDL_Event evento;
    SDL_Color amarillo = {255, 255, 0};
    Uint32 onFocus=SDL_MapRGB(pantalla->format, 0x9e, 0x9e,0x9e);
    for(i=0;i<35;i++){
        palabra[i]='\0';
    }

    fuente = TTF_OpenFont("fonts/visitor.ttf", 22);
    while(!salir){
        while(SDL_PollEvent(&evento)){
                if(evento.type == SDL_KEYUP){
                    switch(evento.key.keysym.sym){
                        case SDLK_KP_ENTER:
                                    salir=true;
                                    break;
                        case SDLK_RETURN:
                                    salir=true;
                                    break;
                        case SDLK_BACKSPACE:
                                    palabra[pos]='\0';
                                    palabra[pos-1]='\0';
                                    pos--;
                                    dim={x-6, y-1, 448, 23};
                                    SDL_FillRect(pantalla, &dim, onFocus);
                                    SDL_Flip(pantalla);
                                    break;
                        case SDLK_ESCAPE:for(i=0;i<35;i++){
                                        palabra[i]='\0';
                                    }
                                    salir=true;
                                    break;
                        default:palabra[pos]=casteo(evento);
                                    pos++;
                                    if(pos>33){
                                        pos=33;
                                    };
                        break;
                    }
                    SDL_FreeSurface(texto);
                    texto = TTF_RenderText_Solid(fuente, palabra, amarillo);
                    apply_surface(x, y, texto, pantalla);
                    SDL_Flip(pantalla);
                }
                if( evento.type == SDL_MOUSEBUTTONUP){
                if( evento.button.button == SDL_BUTTON_LEFT){
                        if((evento.button.x>608&&evento.button.x<640)&&(evento.button.y>0&&evento.button.y<32)){
                            //BOTON X
                            exit(1);
                        }
                    }
                }
        }
    }
    return palabra;
}

void cambiarEstado(int pos){
    //exit(1);
    Nivel reg;
    FILE *archivo;
    FILE *archivoN;
    archivo=fopen("DATA/niveles.dat","rb");
    fseek(archivo, pos*sizeof reg, SEEK_SET);
    fread(&reg, sizeof reg, 1, archivo);
    if(reg.getEstado()==true){reg.setEstado(false);
        }else{reg.setEstado(true);
    }
    fclose(archivo);

    archivoN=fopen("DATA/niveles.dat","rb+");
    fseek(archivoN, pos*sizeof reg, SEEK_SET);
    fwrite(&reg, sizeof reg, 1, archivoN);
    fclose(archivoN);
}

void listarNiveles(SDL_Surface *pantalla){
    bool salir;
    int i, c, y, p=0, r[3];
    FILE *archivo;
    Nivel reg;
    SDL_Surface *fondo = NULL;
    SDL_Surface *fondoN = NULL;
    SDL_Surface *esperar = NULL;
    SDL_Surface *prox = NULL;
    SDL_Surface *prev = NULL;
    SDL_Event evento;
    fondo = IMG_Load("images/bg02.png");
    fondoN = IMG_Load("images/bg02-n.png");
    prox = IMG_Load("images/next.png");
    prev = IMG_Load("images/prev.png");
    esperar = IMG_Load("images/wait.png");

    archivo=fopen("DATA/niveles.dat", "rb");
    if(archivo==NULL){
        apply_surface(0, 0, fondoN, pantalla);
        SDL_Flip(pantalla);
        SDL_Delay(3000);
    }else{
        apply_surface(0, 0, fondo, pantalla);
        for(i=0;i<contarSecciones()*3;i+=3){
            salir=false;
            y=1;
            p++;
            for(c=1;c<=3;c++){
                    if(c==1){fseek(archivo, i*sizeof reg, SEEK_SET);}
                    if(fread(&reg, sizeof reg, 1, archivo)==1){
                    r[c-1]=reg.mostrarNivel(y, pantalla);
                    y=y+2;
                    }
                }
        if(contarSecciones()>1&&i<contarSecciones()+3){
            apply_surface(598, 448, prox, pantalla);
        }
        if(i!=0){
            apply_surface(566, 448, prev, pantalla);
        }
        SDL_Flip(pantalla);
        while(!salir){
            while(SDL_PollEvent(&evento)){
                if(evento.type == SDL_MOUSEBUTTONUP){
                    if( evento.button.button == SDL_BUTTON_LEFT){
                        if((evento.button.x>608&&evento.button.x<640)&&(evento.button.y>0&&evento.button.y<32)){
                            //BOTON X
                            exit(1);
                        }
                        if((evento.button.x>16&&evento.button.x<68)&&(evento.button.y>448&&evento.button.y<476)){
                            //salir
                            i=contarSecciones()*3;
                            salir=true;
                        }
                        if((evento.button.x>566&&evento.button.x<588)&&(evento.button.y>448&&evento.button.y<472)){
                            //<
                            if(i>0){i=i-6;
                                salir=true;
                            }
                        }
                        if((evento.button.x>598&&evento.button.x<620)&&(evento.button.y>448&&evento.button.y<472)){
                            //>
                            if(contarSecciones()>1&&i<contarSecciones()+3)salir=true;
                        }
                        //BUTTONS
                        if(p==contarSecciones()){
                            if(contarNiveles()%3==0){
                                if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>148&&evento.button.y<180)){
                                    cambiarEstado(r[0]-1);
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                 if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>108&&evento.button.y<140)){
                                    reg.cargarNivel(pantalla, buscarNivel(r[0]-1), 'm');
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>266&&evento.button.y<298)){
                                    cambiarEstado(r[1]-1);
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                 if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>226&&evento.button.y<258)){
                                    reg.cargarNivel(pantalla, buscarNivel(r[1]-1), 'm');
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>390&&evento.button.y<422)){
                                    cambiarEstado(r[2]-1);
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                 if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>350&&evento.button.y<382)){
                                    reg.cargarNivel(pantalla, buscarNivel(r[2]-1), 'm');
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                            }
                             if(contarNiveles()%3==2){
                                if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>148&&evento.button.y<180)){
                                    cambiarEstado(r[0]-1);
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                 if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>108&&evento.button.y<140)){
                                    reg.cargarNivel(pantalla, buscarNivel(r[0]-1), 'm');
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>266&&evento.button.y<298)){
                                    cambiarEstado(r[1]-1);
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>226&&evento.button.y<258)){
                                    reg.cargarNivel(pantalla, buscarNivel(r[1]-1), 'm');
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                            }

                             if(contarNiveles()%3==1){
                                if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>148&&evento.button.y<180)){
                                    cambiarEstado(r[0]-1);
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                                if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>108&&evento.button.y<140)){
                                    reg.cargarNivel(pantalla, buscarNivel(r[0]-1), 'm');
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                            }
                        }else{
                            if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>148&&evento.button.y<180)){
                                    cambiarEstado(r[0]-1);
                                    i=contarSecciones()*3;
                                    apply_surface(0, 230, esperar, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(2000);
                                    salir=true;
                                }
                            if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>108&&evento.button.y<140)){
                                reg.cargarNivel(pantalla, buscarNivel(r[0]-1), 'm');
                                i=contarSecciones()*3;
                                apply_surface(0, 230, esperar, pantalla);
                                SDL_Flip(pantalla);
                                SDL_Delay(2000);
                                salir=true;
                            }
                            if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>266&&evento.button.y<298)){
                                cambiarEstado(r[1]-1);
                                i=contarSecciones()*3;
                                apply_surface(0, 230, esperar, pantalla);
                                SDL_Flip(pantalla);
                                SDL_Delay(2000);
                                salir=true;
                            }
                            if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>226&&evento.button.y<258)){
                                reg.cargarNivel(pantalla, buscarNivel(r[1]-1), 'm');
                                i=contarSecciones()*3;
                                apply_surface(0, 230, esperar, pantalla);
                                SDL_Flip(pantalla);
                                SDL_Delay(2000);
                                salir=true;
                            }

                            if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>390&&evento.button.y<422)){
                                cambiarEstado(r[2]-1);
                                i=contarSecciones()*3;
                                apply_surface(0, 230, esperar, pantalla);
                                SDL_Flip(pantalla);
                                SDL_Delay(2000);
                                salir=true;
                            }
                            if((evento.button.x>512&&evento.button.x<608)&&(evento.button.y>350&&evento.button.y<382)){
                                reg.cargarNivel(pantalla, buscarNivel(r[2]-1), 'm');
                                i=contarSecciones()*3;
                                apply_surface(0, 230, esperar, pantalla);
                                SDL_Flip(pantalla);
                                SDL_Delay(2000);
                                salir=true;
                            }
                        }
                    }
                }
            if(i>contarSecciones()*3){i=contarSecciones()*3;}
            }
        apply_surface(0, 0, fondo, pantalla);
            }
        }
    fclose(archivo);
    }

}

#endif // FUNCIONES_H_INCLUDED
