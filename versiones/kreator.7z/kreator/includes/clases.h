#ifndef CLASES_H_INCLUDED
#define CLASES_H_INCLUDED

void apply_surface( int x, int y, SDL_Surface* source, SDL_Surface* destination);
int contarNiveles();
char *escribir(char *, int, int, SDL_Surface *);
bool alert_message(int, int, char *, SDL_Surface*);

class Nivel{
    private:int id;
            char titulo[35];
            char bg[35];
            char fg[35];
            int enemigo1;
            int enemigo2;
            int enemigo3;
            int enemigo4;
            int enemigo5;
            int enemigo6;
            int enemigo7;
            int item1;
            int item2;
            int tiempo;
            bool estado;
    public: Nivel(int, char*, char*, char*, int, int, int, int, int, int, int, int, int, int, bool);
            void setId(int p){id=p;}
            int getId(){return id;}
            void setTitulo(char*p){strcpy(titulo, p);}
            char *getTitulo(){return titulo;}
            void setBg(char*p){strcpy(bg, p);}
            char *getBg(){return bg;}
            void setFg(char*p){strcpy(fg, p);}
            char *getFg(){return fg;}
            void setEnemigo1(int p){if(p<0){p=0;}if(p>30){p=30;}enemigo1=p;}
            int getEnemigo1(){return enemigo1;}
            void setEnemigo2(int p){if(p<0){p=0;}if(p>30){p=30;}enemigo2=p;}
            int getEnemigo2(){return enemigo2;}
            void setEnemigo3(int p){if(p<0){p=0;}if(p>30){p=30;}enemigo3=p;}
            int getEnemigo3(){return enemigo3;}
            void setEnemigo4(int p){if(p<0){p=0;}if(p>30){p=30;}enemigo4=p;}
            int getEnemigo4(){return enemigo4;}
            void setEnemigo5(int p){if(p<0){p=0;}if(p>30){p=30;}enemigo5=p;}
            int getEnemigo5(){return enemigo5;}
            void setEnemigo6(int p){if(p<0){p=0;}if(p>30){p=30;}enemigo6=p;}
            int getEnemigo6(){return enemigo6;}
            void setEnemigo7(int p){if(p<0){p=0;}if(p>30){p=30;}enemigo7=p;}
            int getEnemigo7(){return enemigo7;}
            void setItem1(int p){if(p<0){p=0;}if(p>5){p=5;}item1=p;}
            int getItem1(){return item1;}
            void setItem2(int p){if(p<0){p=0;}if(p>5){p=5;}item2=p;}
            int getItem2(){return item2;}
            void setTiempo(int p){if(p<0){p=0;}if(p>99){p=99;}tiempo=p;}
            int getTiempo(){return tiempo;}
            void setEstado(int p){estado=p;}
            int getEstado(){return estado;}
            void cargarNivel(SDL_Surface *, Nivel, char);
            bool crearNivel();
            bool modificarNivel();
            int mostrarNivel(int, SDL_Surface*);
};

Nivel::Nivel(int id=contarNiveles(), char *titulo="\0", char *bg="\0", char *fg="\0", int enemigo1=0, int enemigo2=0, int enemigo3=0, int enemigo4=0, int enemigo5=0, int enemigo6=0, int enemigo7=0, int item1=0, int item2=0, int tiempo=0, bool estado=true){
    this->id=id+1;
    strcpy(this->titulo, titulo);
    strcpy(this->bg, bg);
    strcpy(this->fg, fg);
    this->enemigo1=enemigo1;
    this->enemigo2=enemigo2;
    this->enemigo3=enemigo3;
    this->enemigo4=enemigo4;
    this->enemigo5=enemigo5;
    this->enemigo6=enemigo6;
    this->enemigo7=enemigo7;
    this->item1=item1;
    this->item2=item2;
    this->tiempo=tiempo;
    this->estado=estado;
}
void Nivel::cargarNivel(SDL_Surface *pantalla, Nivel nuevo, char tipo){
    bool salir = false, pregunta=false;
    int i;
    if(tipo=='a'){nuevo.setId(contarNiveles()+1);}
    SDL_Surface *fondo = NULL;
    SDL_Surface *alerta = NULL;
    SDL_Surface *aviso = NULL;
    SDL_Surface *cursor = NULL;
    SDL_Surface *texto = NULL;
    SDL_Surface *numero = NULL;
    TTF_Font *fuente = NULL;
    SDL_Color negro = {18, 18, 18};
    SDL_Color gris = {168, 168, 168};
    SDL_Color amarillo = {255, 255, 0};
    SDL_Color verde = {14, 185, 0};
    SDL_Color rojo = {255, 0, 0};
    Uint32 onFocus=SDL_MapRGB(pantalla->format, 0x9e, 0x9e,0x9e);
    Uint32 onBlur=SDL_MapRGB(pantalla->format, 0xa8, 0xa8,0xa8);
    SDL_Rect dim;

    SDL_Event evento;

    fuente = TTF_OpenFont("fonts/visitor.ttf", 22);
    if(tipo=='a'){fondo = IMG_Load("images/bg01.png");}
    if(tipo=='m'){fondo = IMG_Load("images/bg03.png");}
    alerta = IMG_Load("images/alerta.png");
    cursor = IMG_Load("images/cursor.png");

    fondo = SDL_DisplayFormat(fondo);

    //SDL_BlitSurface( fondo, NULL, pantalla, NULL );
    apply_surface( 0, 0, fondo, pantalla );
    SDL_Flip(pantalla);

    while(!salir){
        dim={164, 54, 448, 23};
        texto = TTF_RenderText_Solid(fuente, nuevo.getTitulo(), negro);
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(170, 55, texto, pantalla);
        SDL_FreeSurface(texto);

        dim={164, 91, 448, 23};
        texto = TTF_RenderText_Solid(fuente, nuevo.getBg(), negro);
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(170, 92, texto, pantalla);
        SDL_FreeSurface(texto);

        dim={164, 128, 448, 23};
        texto = TTF_RenderText_Solid(fuente, nuevo.getFg(), negro);
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(170, 128, texto, pantalla);
        SDL_FreeSurface(texto);

        char buffer[2];

        sprintf (buffer, "%d", nuevo.getEnemigo1());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={92, 212, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(96, 214, numero, pantalla);
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getEnemigo2());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={92, 256, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(96, 258, numero, pantalla);
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getEnemigo3());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={92, 304, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(96, 306, numero, pantalla);;
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getEnemigo4());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={92, 351, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(96, 353, numero, pantalla);
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getEnemigo5());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={92, 399, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(96, 401, numero, pantalla);
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getEnemigo6());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={252, 212, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(256, 214, numero, pantalla);
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getEnemigo7());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={252, 256, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(256, 258, numero, pantalla);
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getItem1());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={468, 212, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(472, 214, numero, pantalla);
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getItem2());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={468, 249, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(472, 251, numero, pantalla);
        SDL_FreeSurface(numero);

        sprintf (buffer, "%d", nuevo.getTiempo());
        numero = TTF_RenderText_Solid(fuente, buffer, negro);
        dim={560, 385, 32, 23};
        SDL_FillRect(pantalla, &dim, onBlur);
        apply_surface(564, 387, numero, pantalla);
        SDL_FreeSurface(numero);

        SDL_Flip(pantalla);

         while( SDL_PollEvent(&evento)){
            if( evento.type == SDL_MOUSEBUTTONUP){
                if( evento.button.button == SDL_BUTTON_LEFT){
                        if((evento.button.x>608&&evento.button.x<640)&&(evento.button.y>0&&evento.button.y<32)){
                            //BOTON X
                            exit(1);
                        }
                        if((evento.button.x>160&&evento.button.x<618)&&(evento.button.y>48&&evento.button.y<80)){
                            //TITULO
                            dim={164, 54, 448, 23};
                            SDL_FillRect(pantalla, &dim, onFocus);
                            SDL_Flip(pantalla);
                            nuevo.setTitulo(escribir(nuevo.getTitulo(),170,55, pantalla));
                            SDL_FreeSurface(texto);
                            texto = TTF_RenderText_Solid(fuente, nuevo.getTitulo(), negro);
                            SDL_FillRect(pantalla, &dim, onBlur);
                            apply_surface(170, 55, texto, pantalla);
                            SDL_Flip(pantalla);
                        }
                        if((evento.button.x>160&&evento.button.x<618)&&(evento.button.y>84&&evento.button.y<116)){
                            //RUTABG
                            dim={164, 92, 448, 23};
                            SDL_FillRect(pantalla, &dim, onFocus);
                            SDL_Flip(pantalla);
                            nuevo.setBg(escribir(nuevo.getBg(),170,91, pantalla));
                            SDL_FreeSurface(texto);
                            texto = TTF_RenderText_Solid(fuente, nuevo.getBg(), negro);
                            SDL_FillRect(pantalla, &dim, onBlur);
                            apply_surface(170, 92, texto, pantalla);
                            SDL_Flip(pantalla);
                        }
                        if((evento.button.x>160&&evento.button.x<618)&&(evento.button.y>120&&evento.button.y<152)){
                            //RUTAFG
                            dim={164, 128, 448, 23};
                            SDL_FillRect(pantalla, &dim, onFocus);
                            SDL_Flip(pantalla);
                            nuevo.setFg(escribir(nuevo.getFg(),170,128, pantalla));
                            SDL_FreeSurface(texto);
                            texto = TTF_RenderText_Solid(fuente, nuevo.getFg(), negro);
                            SDL_FillRect(pantalla, &dim, onBlur);
                            apply_surface(170, 128, texto, pantalla);
                            SDL_Flip(pantalla);
                        }
                        ///ENEMIGOS
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>208&&evento.button.y<224)){
                            nuevo.setEnemigo1(nuevo.getEnemigo1()+1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>224&&evento.button.y<240)){
                            nuevo.setEnemigo1(nuevo.getEnemigo1()-1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>256&&evento.button.y<268)){
                            nuevo.setEnemigo2(nuevo.getEnemigo2()+1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>268&&evento.button.y<284)){
                            nuevo.setEnemigo2(nuevo.getEnemigo2()-1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>304&&evento.button.y<320)){
                            nuevo.setEnemigo3(nuevo.getEnemigo3()+1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>320&&evento.button.y<336)){
                            nuevo.setEnemigo3(nuevo.getEnemigo3()-1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>352&&evento.button.y<368)){
                            nuevo.setEnemigo4(nuevo.getEnemigo4()+1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>368&&evento.button.y<384)){
                            nuevo.setEnemigo4(nuevo.getEnemigo4()+1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>400&&evento.button.y<416)){
                            nuevo.setEnemigo5(nuevo.getEnemigo5()+1);
                        }
                        if((evento.button.x>128&&evento.button.x<148)&&(evento.button.y>416&&evento.button.y<432)){
                            nuevo.setEnemigo5(nuevo.getEnemigo5()-1);
                        }
                        if((evento.button.x>288&&evento.button.x<308)&&(evento.button.y>208&&evento.button.y<224)){
                            nuevo.setEnemigo6(nuevo.getEnemigo6()+1);
                        }
                        if((evento.button.x>288&&evento.button.x<308)&&(evento.button.y>224&&evento.button.y<240)){
                            nuevo.setEnemigo6(nuevo.getEnemigo6()-1);
                        }
                        if((evento.button.x>288&&evento.button.x<308)&&(evento.button.y>256&&evento.button.y<268)){
                            nuevo.setEnemigo7(nuevo.getEnemigo7()+1);
                        }
                        if((evento.button.x>288&&evento.button.x<308)&&(evento.button.y>268&&evento.button.y<284)){
                            nuevo.setEnemigo7(nuevo.getEnemigo7()-1);
                        }

                        if((evento.button.x>506&&evento.button.x<526)&&(evento.button.y>208&&evento.button.y<224)){
                            nuevo.setItem1(nuevo.getItem1()+1);
                        }
                        if((evento.button.x>506&&evento.button.x<526)&&(evento.button.y>224&&evento.button.y<240)){
                            nuevo.setItem1(nuevo.getItem1()-1);
                        }
                        if((evento.button.x>506&&evento.button.x<526)&&(evento.button.y>246&&evento.button.y<262)){
                            nuevo.setItem2(nuevo.getItem2()+1);
                        }
                        if((evento.button.x>506&&evento.button.x<526)&&(evento.button.y>262&&evento.button.y<278)){
                            nuevo.setItem2(nuevo.getItem2()-1);
                        }
                        if((evento.button.x>596&&evento.button.x<616)&&(evento.button.y>384&&evento.button.y<412)){
                            nuevo.setTiempo(nuevo.getTiempo()+1);
                        }
                        if((evento.button.x>538&&evento.button.x<558)&&(evento.button.y>384&&evento.button.y<412)){
                            nuevo.setTiempo(nuevo.getTiempo()-1);
                        }
                        ///BUTTONS
                        if((evento.button.x>396&&evento.button.x<496)&&(evento.button.y>418&&evento.button.y<452)){
                            salir=true;
                            return;
                        }
                        if((evento.button.x>512&&evento.button.x<612)&&(evento.button.y>418&&evento.button.y<452)){
                             if(tipo=='a'){
                               if(alert_message(640, 480, "�Crear el nivel?",pantalla)){
                                    apply_surface(0, 0, fondo, pantalla);
                                    if(nuevo.crearNivel()){
                                            aviso = IMG_Load("images/create_success.png");
                                       }else{
                                            aviso = IMG_Load("images/create_error.png");
                                       }
                                    apply_surface(0, 230, aviso, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(3000);
                                    salir=true;
                                    return;
                               }else{
                                    apply_surface(0, 0, fondo, pantalla);
                                    SDL_Flip(pantalla);
                               }
                             }
                             if(tipo=='m'){
                               if(alert_message(640, 480, "�Modificar nivel?",pantalla)){
                                    apply_surface(0, 0, fondo, pantalla);
                                    if(nuevo.modificarNivel()){
                                            aviso = IMG_Load("images/create_success.png");
                                       }else{
                                            aviso = IMG_Load("images/create_error.png");
                                       }
                                    apply_surface(0, 230, aviso, pantalla);
                                    SDL_Flip(pantalla);
                                    SDL_Delay(3000);
                                    salir=true;
                                    return;
                               }else{
                                    apply_surface(0, 0, fondo, pantalla);
                                    SDL_Flip(pantalla);
                               }
                             }
                        }
                    }
            }
            if(evento.type == SDL_KEYDOWN){
                //escribir(pantalla, evento);
            }
         }
        SDL_FreeSurface(texto);
    }
    SDL_FreeSurface(fondo);
}


bool Nivel::crearNivel(){
    FILE *archivo;
    archivo=fopen("DATA/niveles.dat", "ab");
    if(archivo==NULL){return false;}
    fwrite(this, sizeof (Nivel), 1, archivo);
    fclose(archivo);
    return true;
}

bool Nivel::modificarNivel(){
    int i=0;
    Nivel reg;
    FILE *archivo;
    archivo=fopen("DATA/niveles.dat", "rb+");

    while(fread(&reg, sizeof reg, 1, archivo)==1){
            if(this->id==reg.getId()){
                fseek(archivo, i*sizeof reg, SEEK_SET);
                if(fwrite(this, sizeof reg, 1, archivo)){
                    fclose(archivo);
                    return true;
                }
            }
            i++;
        }
    fclose(archivo);
    return false;
}
int Nivel::mostrarNivel(int y, SDL_Surface *pantalla){
    SDL_Surface *fondo = NULL;
    SDL_Surface *texto = NULL;
    SDL_Surface *numero = NULL;
    TTF_Font *visitor = NULL;
    TTF_Font *arial = NULL;
    SDL_Color negro = {18, 18, 18};
    Uint32 onBlur=SDL_MapRGB(pantalla->format, 0xa8, 0xa8,0xa8);
    SDL_Rect dim;
    SDL_Event evento;
    y=y*64;

    visitor = TTF_OpenFont("fonts/visitor.ttf", 22);
    arial = TTF_OpenFont("fonts/arial.ttf", 22);
    if(estado==true){
            fondo = IMG_Load("images/reg-a.png");
        }else{
            fondo = IMG_Load("images/reg-d.png");
        }
        apply_surface(0, y, fondo, pantalla);

    texto = TTF_RenderText_Solid(arial, titulo, negro);
    dim={68, y+4, 448, 23};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(72, y+6, texto, pantalla);
    SDL_FreeSurface(texto);

    char buffer[2];

    sprintf (buffer, "%d", id);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={34, y+4, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(34, y+8, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", enemigo1);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={54, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(54, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", enemigo2);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={106, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(106, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", enemigo3);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={156, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(156, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", enemigo4);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={206, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(206, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", enemigo5);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={256, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(256, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", enemigo6);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={306, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(306, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", enemigo7);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={356, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(356, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", item1);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={406, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(406, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    sprintf (buffer, "%d", item2);
    numero = TTF_RenderText_Solid(visitor, buffer, negro);
    dim={456, y+84, 24, 20};
    SDL_FillRect(pantalla, &dim, onBlur);
    apply_surface(456, y+85, numero, pantalla);
    SDL_FreeSurface(numero);

    return id;
}
#endif // CLASES_H_INCLUDED
