#include <iostream>
#include <cstdlib>
#include <string.h>
using namespace std;
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
#include "includes/clases.h"
#include "includes/casteo.h"
#include "includes/funciones.h"

int main( int argc, char* args[] ){
    const int ANCHO = 640;
    const int ALTO = 480;
    const int BPP = 32;
    bool salir = false;
    Nivel nuevo;

    SDL_Init(SDL_INIT_EVERYTHING);
    TTF_Init();
    SDL_Surface *pantalla = NULL;

    pantalla = SDL_SetVideoMode( ANCHO, ALTO, BPP, SDL_NOFRAME);

    SDL_Surface *fondo = NULL;
    SDL_Event evento;

    fondo = IMG_Load("images/bg00.png");
    fondo = SDL_DisplayFormat(fondo);

    while(!salir){
        apply_surface( 0, 0, fondo, pantalla );
        mostrarNumero(contarSecciones(), 172, 456, pantalla);

        SDL_Flip(pantalla);
         while(SDL_PollEvent(&evento)){
            if(evento.type == SDL_MOUSEBUTTONUP){
                if( evento.button.button == SDL_BUTTON_LEFT){
                        if((evento.button.x>608&&evento.button.x<640)&&(evento.button.y>0&&evento.button.y<32)){
                            //BOTON X
                            exit(1);
                        }
                        if((evento.button.x>212&&evento.button.x<428)&&(evento.button.y>198&&evento.button.y<230)){
                            nuevo.cargarNivel(pantalla, nuevo, 'a');
                        }
                        if((evento.button.x>212&&evento.button.x<428)&&(evento.button.y>242&&evento.button.y<274)){
                            listarNiveles(pantalla);
                        }
                        if((evento.button.x>212&&evento.button.x<428)&&(evento.button.y>282&&evento.button.y<314)){
                            exit(1);
                        }
                    }
            }
         }
    }

    SDL_FreeSurface(fondo);
    SDL_Quit();
    return 0;
}
